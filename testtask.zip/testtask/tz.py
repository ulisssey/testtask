import os
import pandas as pd


def check_folders(folder):
    n = []
    names = []
    extensions = []
    for root, dirs, files in os.walk(folder):
        for file in files:
            n.append(root)
            names.append(get_filename(file))
            extensions.append(get_extension(file))
    dt = pd.DataFrame({'Root': n, 'Filename': names, 'extensions': extensions})
    dt.to_excel('./result.xlsx')


def get_filename(filename):
    if '.' in filename:
        return filename.split('.')[0]
    else:
        return filename


def get_extension(filename):
    if '.' in filename:
        return filename.split('.')[-1]
    else:
        pass
check_folders('.')